<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HuurtoeslagMain</title>
    <link rel="stylesheet" href="./Huurtoeslag_V1.css">
</head>
<body>
<?php
        require "../Footer_And_Header/Navbar.php";
    ?>
        <section class="hero">
            <div class="container">
                <h2>Rental Allowance</h2>
                <a href="HuurtoeslagAanvragen.php">Apply for housing allowance</a>
                <a href="HuurtoeslagInfo.php">Questions about rental allowance</a>
            </div>
        </section>
        <?php
        require "../Footer_And_Header/Footer.php";
    ?>
</body>

</html>