<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Huurtoeslag</title>
    <link rel="stylesheet" href="./Huurtoeslag_V2.css">
</head>
<body>
    <?php
        require "../Footer_And_Header/Navbar.php";
    ?>

    <section class="hero">
        <div class="container">
            <h2>Rental Allowance Request</h2>
            <form action="Aanvragen.php" method="post">
                <label for="naam">Name:</label>
                <input type="text" id="naam" name="naam" required><br><br>

                <label for="adres">Address:</label>
                <input type="text" id="adres" name="adres" required><br><br>

                <label for="postcode">ZipCode:</label>
                <input type="text" id="postcode" name="postcode" required><br><br>

                <label for="plaats">Location:</label>
                <input type="text" id="plaats" name="plaats" required><br><br>

                <label for="huurprijs">Rental Price:</label>
                <input type="number" id="huurprijs" name="huurprijs" required><br><br>

                <label for="inkomen">Income:</label>
                <input type="number" id="inkomen" name="inkomen" required><br><br>

                <input type="submit" value="Request">

                <br>
                <a id="back" href="HuurtoeslagMain.php" class="back-btn">Back</a>
            </form>
        </div>
    </section>

    <?php
        require "../Footer_And_Header/Footer.php";
    ?>
</body>
</html>
