<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HuurToeslagInfo</title>
    <link rel="stylesheet" href="./Huurtoeslag_V3.css">
</head>
<body>
    <?php
        require "../Footer_And_Header/Navbar.php";
    ?>

    <section class="hero">
        <div class="container">
            <h2>Rental Allowance Information</h2>
            <p>Everything for your rental allowances</p>
        </div>
        
        <!-- Nieuwe sectie voor huurtoeslag informatie -->
        <section class="huurtoeslag-info">
            <div class="container">
                <h2>Rent allowance: How does it work?</h2>
                <p>Rent allowance is a financial contribution from the government to help tenants pay their rent.</p>
                
                <h3>Who is eligible for housing allowance?</h3>
                <ul>
                    <li>You must have a rental property with a rent that is below the rental allowance limit.</li>
                    <li>You must have a low income.</li>
                    <li>You must have Dutch nationality or a valid residence permit.</li>
                </ul>
                
                <h3>How do I apply for housing allowance?</h3>
                <p>You can apply for housing allowance via the Tax Authorities website or at a town hall.</p>
                
                <h3>What are the documents I need?</h3>
                <ul>
                    <li>A copy of your ID.</li>
                    <li>A copy of your rental contract.</li>
                    <li>A copy of your income allowance.</li>
                </ul>

                <br>
                <a href="HuurtoeslagMain.php" class="btn">Back</a>
            </div>
        </section>
    </section>

    <?php
        require "../Footer_And_Header/Footer.php";
    ?>
</body>
</html>
