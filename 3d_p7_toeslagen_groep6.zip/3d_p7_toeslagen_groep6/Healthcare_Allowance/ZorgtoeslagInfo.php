<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare Allowance Information</title>
    <link rel="stylesheet" href="./Zorgtoeslag_V2.css">
</head>
<body>
<?php
        require "../Footer_And_Header/Navbar.php";
    ?>
   
        <section class="hero">
            <div class="container">
            <h2>Healthcare Allowance Information</h2>
            <p>Everything for your Healthcare Allowances</p>
            </div>
              <!-- Nieuwe sectie voor huurtoeslag informatie -->
        <section class="huurtoeslag-info">
            <div class="container">
            
<h2>Healthcare Allowance: How does it work?</h2>
<p>Healthcare allowance is a financial contribution from the government to help individuals pay for their healthcare costs.</p>
<h3>Who is eligible for healthcare allowance?</h3>
<ul>
    <li>You must have a low income.</li>
    <li>You must have Dutch nationality or a valid residence permit.</li>
    <li>You must have healthcare insurance.</li>
</ul><br>
<h3>How do I apply for healthcare allowance?</h3><br>
<p>You can apply for healthcare allowance via the Tax Authorities website or at a town hall.</p>
<h3>What are the documents I need?</h3>
<ul>
    <li>A copy of your ID.</li>
    <li>A copy of your healthcare insurance policy.</li>
    <li>A copy of your income statement.</li>
</ul>

<br>
<a href="ZorgtoeslagMain.php">Back</a>
            </div>
        </section>
        
        </section>
    </section>
    <?php
        require "../Footer_And_Header/Footer.php";
    ?>
    </body>

</html>

