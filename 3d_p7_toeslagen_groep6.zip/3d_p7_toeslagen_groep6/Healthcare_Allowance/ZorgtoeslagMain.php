<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare Allowance Main</title>
    <link rel="stylesheet" href="./Zorgtoeslag_V3.css">
</head>
<body>
<?php
        require "../Footer_And_Header/Navbar.php";
    ?>
   
        <section class="hero">
            <div class="container">
            <h2>Healthcare Allowance</h2>
                <a href="ZorgToeslagAanvragen.php">Apply for Healthcare Allowance</a>
                <a href="ZorgtoeslagInfo.php">Questions about Healthcare Allowance</a>   </div>
        </section>
    </section>
    <?php
        require "../Footer_And_Header/Footer.php";
    ?>
</body>

</html>