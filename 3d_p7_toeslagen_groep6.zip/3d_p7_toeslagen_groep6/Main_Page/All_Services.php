<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Services - GemaTax</title>
    <link rel="stylesheet" href="./All_Services.css">
</head>
<body>

    <?php require "./../Footer_And_Header/Navbar.php"; ?>

    <section class="services-container">
        <div class="service-card">
            <a href="../Healthcare_Allowance/ZorgtoeslagMain.php">
                <img src="../Pictures/income-tax.jpg" alt="Income Tax Services">
                <div class="service-details">
                    <h3>Healthcare Allowance</h3>
                    <p>Let us help you claim the maximum healthcare allowance you're entitled to. Our experts make the process simple, ensuring accurate and timely submissions so you can focus on your health. Contact us today to learn more!</p>
                </div>
            </a>
        </div>

        <div class="service-card">
            <a href="../Child_Allowance/KindertoeslagMain.php">
                <img src="../Pictures/Corp tax.jpeg" alt="Child Allowance Services">
                <div class="service-details">
                    <h3>Child Allowance</h3>
                    <p>Maximize your child allowance claims and ensure you’re receiving the benefits you're entitled to.</p>
                </div>
            </a>
        </div>

        <div class="service-card">
            <a href="../Rental_Allowance/HuurtoeslagMain.php">
                <img src="../Pictures/Tax.jpg" alt="Rental Allowance Services">
                <div class="service-details">
                    <h3>Rental Allowance</h3>
                    <p>Get assistance with applying for rental allowance and managing your housing benefits.</p>
                </div>
            </a>
        </div>
    </section>

    <?php require "./../Footer_And_Header/Footer.php"; ?>

</body>
</html>
