<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GemaTax – Official Tax Services</title>
    <link rel="stylesheet" href="./Homepage.css">
    <link rel="stylesheet" href="./Categories.css">
</head>
<body>

    <?php require "./../Footer_And_Header/Navbar.php"; ?>

    <section class="slideshow-container">
        <div class="slides">
            <div class="slide fade">
                <img src="../Pictures/familie-in-keuken.jpg" alt="Filing your income tax online">
            </div>
            <div class="slide fade">
                <img src="../Pictures/cp-home-bruiloftstel-in-feestzaal (1).jpg" alt="Tax consultation services">
            </div>
            <div class="slide fade">
                <img src="../Pictures/voorlopigeaanslag2.png" alt="Business tax assistance">
            </div>
        </div>

        <!-- Dots below the slideshow -->
        <div class="dot-container">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>
    </section>

    <div class="main-wrapper">
        <div class="category-navigation">
            <a href="./All_Services.php">Browse All Services</a>
        </div>
        <div class="category-display">
            <div class="large-category">
                <a href="../Healthcare_Allowance/ZorgtoeslagMain.php">
                    <img src="../Pictures/income-tax.jpg" alt="Income Tax Services">
                    <div class="card-content">
                        <h3>Healthcare Allowance</h3>
                        <a href="../Healthcare_Allowance/ZorgtoeslagMain.php">Explore Healthcare Allowance Services</a>
                    </div>
                </a>
            </div>

            <div class="small-categories">
                <div class="category-card">
                    <a href="../Child_Allowance/KindertoeslagMain.php">
                        <img src="../Pictures/Corp tax.jpeg" alt="Business Tax Services">
                        <div class="card-content">
                            <h3>Child Allowance</h3>
                            <a href="../Child_Allowance/KindertoeslagMain.php">Explore Child Allowance Services</a>
                        </div>
                    </a>
                </div>
                <div class="category-card">
                    <a href="../Rental_Allowance/HuurtoeslagMain.php">
                        <img src="../Pictures/Tax.jpg" alt="VAT Registration Services">
                        <div class="card-content">
                            <h3>Rental Allowance</h3>
                            <a href="../Rental_Allowance/HuurtoeslagMain.php">Explore Rental Allowance Services</a>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php require "./../Footer_And_Header/Footer.php"; ?>

    <script src="../JScript/Slideshow.js"></script>
</body>
</html>
