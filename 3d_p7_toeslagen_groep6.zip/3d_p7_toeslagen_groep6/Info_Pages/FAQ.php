    <?php
        require "../Footer_And_Header/Navbar.php";
    ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./FAQ.css">
    <title>FAQ - Gematax</title>
</head>
<body>
    <section id="faq">
    <br> <br> <br> <br> <br>
        <h2>Frequently Asked Questions (FAQ)</h2>
        <div class="faq-item">
            <h3>What is Gematax?</h3>
            <p>Gematax is a tax advisory service that helps businesses and individuals with tax returns, advice, and tax planning. Our goal is to make the tax process as simple and transparent as possible.</p>
        </div>
        <div class="faq-item">
            <h3>How can I submit my tax return?</h3>
            <p>You can easily submit your tax return online via our website. We also provide in-person support for complex cases or for clients who prefer face-to-face assistance.</p>
        </div>
        <div class="faq-item">
            <h3>What does it cost to use Gematax services?</h3>
            <p>Our pricing varies depending on the services you require. We offer both standard packages and custom advice. Contact us for a quote that suits your needs.</p>
        </div>
        <div class="faq-item">
            <h3>Can I get tax advice for my business?</h3>
            <p>Yes, we offer comprehensive tax advisory services for businesses of all sizes. Whether you are just starting out or have an established company, we can help with tax planning and optimization.</p>
        </div>
        <div class="faq-item">
            <h3>How can I contact Gematax?</h3>
            <p>You can reach us via our contact form on the website or by sending an email to info@gematax.com. You can also call us at: 123-4567890.</p>
        </div>
    </section>
</body>
</html>


    <?php
    require "../Footer_And_Header/Footer.php";
    ?>