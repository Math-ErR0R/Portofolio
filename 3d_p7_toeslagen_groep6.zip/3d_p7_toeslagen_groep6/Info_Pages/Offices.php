<?php
    require "../Footer_And_Header/Navbar.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Offices.css">
    <link rel="stylesheet" href="./Office_Categories.CSS">
    <title>Our Offices - Gematax</title>
</head>
<body>
    <section id="our-offices">
    <br> <br> <br> <br> <br>
        <h2>Our Offices</h2>
        <div class="office-box">
            <div class="office">
                <h3>Headquarters</h3>
                <p>Address: Main Street 123, 1011 AB Amsterdam</p>
                <p>Phone: 020-1234567</p>
                <p>Email: amsterdam@gematax.com</p>
            </div>
        </div>
        <div class="office-box">
            <div class="office">
                <h3>Rotterdam Branch</h3>
                <p>Address: Rotterdam Road 45, 3014 AB Rotterdam</p>
                <p>Phone: 010-9876543</p>
                <p>Email: rotterdam@gematax.com</p>
            </div>
        </div>
        <div class="office-box">
            <div class="office">
                <h3>Utrecht Branch</h3>
                <p>Address: Old Canal 9, 3511 AA Utrecht</p>
                <p>Phone: 030-1122334</p>
                <p>Email: utrecht@gematax.com</p>
            </div>
        </div>
    </section>
</body>
</html>

<?php
require "../Footer_And_Header/Footer.php";
?>
