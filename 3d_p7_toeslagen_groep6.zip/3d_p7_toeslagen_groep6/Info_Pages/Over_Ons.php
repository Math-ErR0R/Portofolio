    <?php
        require "../Footer_And_Header/Navbar.php";
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./Over_Ons.css">
        <title>About Us - Gematax</title>
    </head>
    <body>
        <section id="about-us">
        <br> <br> <br> <br> <br>
            <h2>About Gematax</h2>
            <p>Gematax is a tax advisory firm focused on providing reliable tax services to both businesses and individuals. With years of experience in the field, we strive to achieve the highest level of customer satisfaction by offering personal advice and professional service.</p>
            <p>Our tax advisors work closely with clients to achieve tax savings and assist them in navigating through complex tax regulations. Whether you need to file a tax return, seek advice on tax planning, or have a specific tax issue, Gematax is here to help.</p>
            <p>At Gematax, integrity, transparency, and customer satisfaction are at the heart of everything we do. We provide tailored solutions that align with your unique needs, ensuring that your tax matters are handled efficiently and stress-free.</p>
        </section>
    </body>
    </html>

    <?php
    require "../Footer_And_Header/Footer.php";
    ?>