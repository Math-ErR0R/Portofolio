<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KindertoeslagMain</title>
    <link rel="stylesheet" href="./Kindertoeslag_V1.css">
</head>
<body>
    <?php
        require "../Footer_And_Header/Navbar.php";
    ?>

    <section class="hero">
        <div class="container">
            <h2>Child Benefit</h2>
            <a href="Kindertoeslag.php" class="btn">Apply for Benefits</a>
            <a href="KindertoeslagInfo.php" class="btn">Questions about Child Benefit</a>
        </div>
    </section>

    <?php
        require "../Footer_And_Header/Footer.php";
    ?>
</body>
</html>
