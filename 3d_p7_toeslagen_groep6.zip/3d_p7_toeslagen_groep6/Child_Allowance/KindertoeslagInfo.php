<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KinderToeslagInfo</title>
    <link rel="stylesheet" href="./Kindertoeslag_V3.css">
</head>
<body>
    <?php
        require "../Footer_And_Header/Navbar.php";
    ?>
   
        <section class="hero">
            <div class="container">
            <h2>Rent allowance Information</h2>
            <p>Everything for your rental allowances</p>
            </div>
              <!-- Nieuwe sectie voor huurtoeslag informatie -->
        <section class="huurtoeslag-info">
            <div class="container">
            <h1>Child Benefit Information Page</h1> <h2>Introduction</h2> <p>Child benefit is a financial contribution from the government to help parents raise their children. Below you will find more information about child benefit, who is eligible, and how to apply for it.</p> <h2>Who is eligible for child benefit?</h2> <ul> <li>You must have a child who is under 18 years old.</li> <li>You must have a low income.</li> <li>You must have Dutch nationality or a valid residence permit.</li> <li>You must have a child living in your household.</li> </ul> <h2>How does child benefit work?</h2> <p>Child benefit is a monthly allowance that you receive to raise your children. The amount of the allowance depends on your income and the number of children you have.</p> <h2>What documents do I need?</h2> <ul> <li>A copy of your identification.</li> <li>A copy of your rental contract or mortgage deed.</li> <li>A copy of your income statement.</li> <li>A copy of your child(ren)'s birth certificate(s).</li> </ul> <h2>How do I apply for child benefit?</h2> <p>You can apply for child benefit through the Tax Authority's website or at a municipal office. You must bring all necessary documents to support your application.</p> <h2>When can I expect child benefit?</h2> <p>You can expect child benefit within 6-8 weeks after your application. You will receive a letter from the Tax Authority with information about your allowance.</p> <h2>How long does the allowance last?</h2> <p>The allowance lasts as long as your child(ren) are under 18 years old. You must report your income and family situation to the Tax Authority annually to maintain your allowance.</p> 
            <h2>More information</h2> <p>You can find more information about child benefit on the Tax Authority's website. You can also contact the Tax Authority to ask your questions.</p>

                <br>
                <a href="KindertoeslagMain.php">Back</a>
            </div>
        </section>
        
        </section>
    </section>
    <?php
        require "../Footer_And_Header/Footer.php";
    ?>
    </body>

</html>

