<?php
require_once '../../Database/database.php';
$query = "SELECT * FROM kindertoeslag";
$stmt = $conn->prepare($query);
$stmt->execute();

// Check if there are any results
if ($stmt->rowCount() > 0) {
    // Display the results
    echo "<h2>Kindertoeslag Results</h2>";
    echo "<table border='1'>";
    echo "<tr><th>KinderID</th><th>Naam</th><th>Adres</th><th>Postcode</th><th>Woonplaats</th><th>Telefoonnummer</th><th>Email</th><th>Kinderen</th><th>Inkomen</th><th>Allowance</th></tr>";

    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Calculate allowance
        $allowance = ($row["kinderen"] * 100) + ($row["inkomen"] * 0.4);

        echo "<tr>";
        echo "<td>" . $row["KinderID"] . "</td>";
        echo "<td>" . $row["naam"] . "</td>";
        echo "<td>" . $row["adres"] . "</td>";
        echo "<td>" . $row["postcode"] . "</td>";
        echo "<td>" . $row["woonplaats"] . "</td>";
        echo "<td>" . $row["telefoonnummer"] . "</td>";
        echo "<td>" . $row["email"] . "</td>";
        echo "<td>" . $row["kinderen"] . "</td>";
        echo "<td>" . $row["inkomen"] . "</td>";
        echo "<td>" . $allowance . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "No results found.";
}


?>