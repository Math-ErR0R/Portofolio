<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kindertoeslag</title>
    <link rel="stylesheet" href="../../CSS/Declerations.CSS">
</head>
<body>
<?php
        require "../Footer_And_Header/Navbar.php";
    ?>

    <section class="hero">
        <div class="container">
        </div>

        <h2>Kindertoeslag Aanvragen</h2>
        <form action="Aanvragen.php" method="post">
            <label for="naam">Name:</label>
            <input type="text" id="naam" name="naam" required><br><br>
            
            <label for="adres">Address:</label>
            <input type="text" id="adres" name="adres" required><br><br>
            
            <label for="postcode">ZipCode:</label>
            <input type="text" id="postcode" name="postcode" required><br><br>
            
            <label for="woonplaats">Location:</label>
            <input type="text" id="woonplaats" name="woonplaats" required><br><br>
            
            <label for="telefoonnummer">Phone Number:</label>
            <input type="text" id="telefoonnummer" name="telefoonnummer" required><br><br>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br><br>
            
            <label for="kinderen">Number of Children:</label>
            <input type="number" id="kinderen" name="kinderen" required><br><br>
            
            <label for="inkomen">Income:</label>
            <input type="number" id="inkomen" name="inkomen" required><br><br>
            
            <input type="submit" value="Request">
        </form>

        <br>
        <a href="KindertoeslagMain.php">Back</a>
    </section>
    <?php
        require "../Footer_And_Header/Footer.php";
    ?>
</body>
</html>
