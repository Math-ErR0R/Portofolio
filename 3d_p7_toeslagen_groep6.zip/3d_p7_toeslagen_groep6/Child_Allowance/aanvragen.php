<?php
// Include database connection
require_once '../../database/database.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize the form input
    $naam = $_POST["naam"];
    $adres = $_POST["adres"];
    $postcode = $_POST["postcode"];
    $woonplaats = $_POST["woonplaats"];
    $telefoonnummer = $_POST["telefoonnummer"];
    $email = $_POST["email"];
    $kinderen = $_POST["kinderen"];
    $inkomen = $_POST["inkomen"];

    // Calculate the subsidy based on income
    $toeslag = 0;
    if ($inkomen < 20000) {
        $toeslag = 1000;
    } elseif ($inkomen < 30000) {
        $toeslag = 500;
    } else {
        $toeslag = 0;
    }

    try {
        // Prepare SQL query to insert data using prepared statements
        $sql = "INSERT INTO kindertoeslag (naam, adres, postcode, woonplaats, telefoonnummer, email, kinderen, inkomen) 
                VALUES (:naam, :adres, :postcode, :woonplaats, :telefoonnummer, :email, :kinderen, :inkomen)";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':naam', $naam);
        $stmt->bindParam(':adres', $adres);
        $stmt->bindParam(':postcode', $postcode);
        $stmt->bindParam(':woonplaats', $woonplaats);
        $stmt->bindParam(':telefoonnummer', $telefoonnummer);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':kinderen', $kinderen);
        $stmt->bindParam(':inkomen', $inkomen);
       
        // Execute the query
        $stmt->execute();

        // Success message
        echo "Aanvraag is succesvol verstuurd!<br>";
        echo "Toeslag berekend: €" . $toeslag;
    } catch (PDOException $e) {
        // Error handling
        echo "Error: " . $e->getMessage();
    }
}
?>
