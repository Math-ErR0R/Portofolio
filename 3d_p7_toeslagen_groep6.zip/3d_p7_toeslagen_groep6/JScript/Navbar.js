window.addEventListener('scroll', function() {
  var header = document.querySelector('header');
  if (window.scrollY > 0) {
      header.classList.add('scrolled');
  } else {
      header.classList.remove('scrolled');
  }
});

function toggleDropdown() {
  var dropdownContent = document.getElementById("dropdownContent");
  if (dropdownContent.style.display === "none" || dropdownContent.style.display === "") {
      dropdownContent.style.display = "block";
  } else {
      dropdownContent.style.display = "none";
  }
}

function toggleSearch() {
  var searchDropdown = document.getElementById("searchDropdown");
  if (searchDropdown.style.display === "none" || searchDropdown.style.display === "") {
      searchDropdown.style.display = "block";
  } else {
      searchDropdown.style.display = "none";
  }
}

function filterFunction() {
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  ul = document.getElementById("searchResults");
  li = ul.getElementsByTagName("li");

  for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName("a")[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
      } else {
          li[i].style.display = "none";
      }
  }
}

// Close the dropdowns if clicked outside
window.addEventListener('click', function(event) {
    var dropdown = document.getElementById("dropdownContent");
    var searchDropdown = document.getElementById("searchDropdown");
  
    if (!event.target.matches('.login img') && !dropdown.contains(event.target) && dropdown.style.display === "block") {
        dropdown.style.display = "none";
    }
  
    if (!event.target.matches('.zoek img') && !searchDropdown.contains(event.target) && searchDropdown.style.display === "block") {
        searchDropdown.style.display = "none";
    }
  });
  
