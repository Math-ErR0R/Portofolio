var slideIndex = 0;
showSlides();  // Call the function once to initialize the first slide

// Function to show the slides
function showSlides() {
    var slides = document.getElementsByClassName("slide");
    var dots = document.getElementsByClassName("dot");

    // Hide all slides
    for (var i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    // Reset all dot active classes
    for (var i = 0; i < dots.length; i++) {
        dots[i].classList.remove("active");
    }

    // Increment slideIndex and reset it if it exceeds the total slides count
    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1; }

    // Show the current slide
    slides[slideIndex - 1].style.display = "block";

    // Add the active class to the corresponding dot
    dots[slideIndex - 1].classList.add("active");

    // Change slide every 6 seconds
    setTimeout(showSlides, 6000);
}

// Function to navigate to the current slide based on dot clicks
function currentSlide(n) {
    slideIndex = n - 1;
    showSlides();  // Call showSlides to refresh the slides
}
