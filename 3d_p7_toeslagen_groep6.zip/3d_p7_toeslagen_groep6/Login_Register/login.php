<?php

$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $mysqli = require __DIR__ . "/database.php"; // Include database connection
    
    // Change to account table and correct column names (Email, Wachtwoord, BurgerID)
    $email = $mysqli->real_escape_string($_POST["email"]); // Escape the email input
    $sql = "SELECT * FROM account WHERE Email = '$email'"; // Correct table and column names
    
    $result = $mysqli->query($sql);  // Execute query
    
    $user = $result->fetch_assoc();  // Fetch user data
    
    if ($user) {
        // Verify the password using the hashed password in the database
        if (password_verify($_POST["password"], $user["Wachtwoord"])) {
            
            session_start();
            session_regenerate_id();
            $_SESSION["user_id"] = $user["BurgerID"]; // Store the BurgerID in the session
            
            header("Location: ../Main_Page/Homepage.php");  // Redirect to home page after successful login
            exit;
        }
    }
    
    $is_invalid = true;  // Set invalid flag if login fails
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <h1>Login</h1>
    
    <?php if ($is_invalid): ?>
        <script type="text/javascript">alert("Wachtwoord is onjuist")</script>
    <?php endif; ?>


    
    <form method="post">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($_POST["email"] ?? "") ?>" required>
        
        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>
        
        <button type="submit">Log in</button>
    </form>

    <a href="forgot-password.php">Forgot password?</a>
    
</body>
</html>
