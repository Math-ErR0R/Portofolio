<?php
// Basic home page in PHP with a "Log in or sign up" link
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="style.css"> <!-- Link to the CSS file -->
</head>
<body>
    <h1>Home</h1>
    <p><a href="login.php" class="auth-link">Log in</a> or <a href="signup.html" class="auth-link">sign up</a></p>
</body>
</html>
