<?php

$token = $_POST["token"]; // The token from the form
$token_hash = hash("sha256", $token); // Hash the token for comparison

$mysqli = require __DIR__ . "/database.php"; // Database connection

// Check if the token is valid in the account table
$sql = "SELECT * FROM account WHERE reset_token_hash = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $token_hash);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user === null) {
    die("Token not found");
}

if (strtotime($user["reset_token_expires_at"]) <= time()) {
    die("Token has expired");
}

// Validate the password
if (strlen($_POST["password"]) < 8) {
    die("Password must be at least 8 characters");
}

if (!preg_match("/[a-z]/i", $_POST["password"])) {
    die("Password must contain at least one letter");
}

if (!preg_match("/[0-9]/", $_POST["password"])) {
    die("Password must contain at least one number");
}

if ($_POST["password"] !== $_POST["password_confirmation"]) {
    die("Passwords must match");
}

$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the new password

// Updated SQL query - no comments inside the query
$sql = "UPDATE account
        SET Wachtwoord = ?, 
            reset_token_hash = NULL, 
            reset_token_expires_at = NULL
        WHERE BurgerID = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("ss", $password_hash, $user["BurgerID"]);
$stmt->execute();

echo "Password updated. You can now login.";

?>
