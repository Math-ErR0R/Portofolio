<?php
// Check if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request. Form not submitted via POST.");
}

// 1. Validate fields
if (empty($_POST["name"])) {
    die("Name is required");
}

if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
    die("Valid email is required");
}

if (strlen($_POST["password"]) < 8) {
    die("Password must be at least 8 characters");
}

if (!preg_match("/[a-z]/i", $_POST["password"])) {
    die("Password must contain at least one letter");
}

if (!preg_match("/[0-9]/", $_POST["password"])) {
    die("Password must contain at least one number");
}

if ($_POST["password"] !== $_POST["password_confirmation"]) {
    die("Passwords must match");
}

// 2. Check if the birthdate is provided
if (empty($_POST["birthdate"])) {
    die("Birthdate is required");
}

// Check if the birthdate has the correct format (YYYY-MM-DD)
$birthdate = $_POST["birthdate"];
$birthdateObj = DateTime::createFromFormat('Y-m-d', $birthdate);
if (!$birthdateObj || $birthdateObj->format('Y-m-d') !== $birthdate) {
    die("Invalid birthdate format (YYYY-MM-DD required)");
}

// 3. Hash the password
$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);

// 4. Connect to the database
require __DIR__ . "/database.php";
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 5. Calculate the age based on birthdate
$today = new DateTime();
$age = $today->diff($birthdateObj)->y;  // Difference in years

// 6. Build the SQL query
$sql = "INSERT INTO account (Voornaam, Email, Wachtwoord, Geboortedatum, Leeftijd)
        VALUES (?, ?, ?, ?, ?)";

// 7. Prepare statement to prevent SQL injection
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL error: " . $conn->error);
}

// 8. Bind the parameters and execute the query
$stmt->bind_param(
    "sssss",
    $_POST["name"],  // First name
    $_POST["email"], // Email
    $password_hash,  // Password hash
    $birthdate,      // Birthdate
    $age             // Age
);

if ($stmt->execute()) {
    echo "Account successfully created!";
} else {
    die("Error inserting into database: " . $stmt->error);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
