<?php
// Check if the token is set in the URL
if (isset($_GET["token"])) {
    $token = $_GET["token"];  // Get the reset token from the URL
} else {
    die("No token found in the URL.");
}

$token_hash = hash("sha256", $token);  // Hash the token

// Database connection
$mysqli = require __DIR__ . "/database.php"; // Make sure the database connection is correct

// Prepare the SQL query to fetch user based on token
$sql = "SELECT * FROM account WHERE reset_token_hash = ?";  // Using 'account' table
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $token_hash);  // Bind the token hash to the query
$stmt->execute();
$result = $stmt->get_result();

$user = $result->fetch_assoc();  // Fetch the user record

// If no user found, token is invalid
if ($user === null) {
    die("Token not found");
}

// If the token has expired
if (strtotime($user["reset_token_expires_at"]) <= time()) {
    die("Token has expired");
}

// Continue with the rest of the page (show password reset form)
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
</head>
<body>
    <h1>Reset Password</h1>

    <form method="post" action="process-reset-password.php">
        <!-- Hidden field for passing token -->
        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">

        <label for="password">New password:</label>
        <input type="password" id="password" name="password" required>

        <label for="password_confirmation">Repeat password:</label>
        <input type="password" id="password_confirmation" name="password_confirmation" required>

        <button type="submit">Submit</button>
    </form>

</body>
</html>
