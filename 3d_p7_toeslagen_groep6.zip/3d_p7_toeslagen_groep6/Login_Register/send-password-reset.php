<?php

$email = $_POST["email"]; // Get the email entered by the user

// Generate a random token for the password reset link
$token = bin2hex(random_bytes(16));

// Hash the token
$token_hash = hash("sha256", $token);

// Set an expiry time for the token (30 minutes from now)
$expiry = date("Y-m-d H:i:s", time() + 60 * 30);

// Database connection
$mysqli = require __DIR__ . "/database.php";

// Update the user record with the reset token and its expiry time in the account table
$sql = "UPDATE account
        SET reset_token_hash = ?,
            reset_token_expires_at = ?
        WHERE Email = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("sss", $token_hash, $expiry, $email);
$stmt->execute();

// If the email exists in the database, send the reset email
if ($mysqli->affected_rows) {

    // Use PHPMailer (or another mail library) to send the email
    $mail = require __DIR__ . "/mailer.php";

    $mail->setFrom("noreply@example.com");
    $mail->addAddress($email);
    $mail->Subject = "Password Reset";
    $mail->Body = <<<END

    Click <a href="http://example.com/reset-password.php?token=$token">here</a> 
    to reset your password.

    END;

    try {
        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer error: {$mail->ErrorInfo}";
    }

    echo "Message sent, please check your inbox.";

} else {
    echo "No account found with that email.";
}
?>
