<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <h1>Forgot Password</h1>

    <!-- Form to enter the email address for the reset request -->
    <form method="post" action="send-password-reset.php">

        <label for="email">Email</label>
        <input type="email" name="email" id="email" required>

        <button>Send</button>

    </form>

</body>
</html>
