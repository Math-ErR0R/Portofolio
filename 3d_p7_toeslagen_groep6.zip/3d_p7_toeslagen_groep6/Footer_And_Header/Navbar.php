<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../Footer_And_Header/Navbar.CSS">
    <title>Gematax</title>
</head>
<body>
    <header>
        <nav>
            <!-- Logo -->
            <div class="logo">
                <img src="./../Pictures/Logo.png" alt="Gematax Logo" height="90">
            </div>

            <!-- Dropdown for Login/Registration -->
            <div class="dropdown">
                <div class="login">
                    <img src="./../Pictures/Login.png" alt="login_icon" height="45" onclick="toggleDropdown()">
                    <div id="dropdownContent" class="dropdown-content">
                        <a href="./../Login_Register/login.php">Login</a>
                        <a href="./../Login_Register/signup.php">Register</a>
                    </div>
                </div>
            </div>

            <!-- Search bar -->
            <div class="zoek">
                <img src="./../Pictures/Vergrootglas.png" alt="search_icon" height="45" onclick="toggleSearch()" />
                <div id="searchDropdown" class="dropdown-content" style="display: none;">
                    <input type="text" placeholder="Search..." id="myInput" onkeyup="filterFunction()">
                    <ul id="searchResults">
                        <li><a href="./../Main_Page/Homepage.php">Homepage</a></li>
                        <br>
                        <li><a href="./../Rental_Allowance/Huurtoeslagmain.php">Rental Allowance</a></li>
                        <br>
                        <li><a href="./../Child_Allowance/KindertoeslagMain.php">Child Allowance</a></li>
                        <br>
                        <li><a href="./../Healthcare_Allowance/ZorgtoeslagMain.php">Healthcare Allowance</a></li>
                    </ul>
                </div>
            </div>

            <!-- Navigation Links -->
            <ul>
                <li><a href="./../Main_Page/Homepage.php">Homepage</a></li>
                <li><a href="./../Rental_Allowance/Huurtoeslagmain.php">Rental Allowance</a></li>
                <li><a href="./../Child_Allowance/KindertoeslagMain.php">Child Allowance</a></li>
                <li><a href="./../Healthcare_Allowance/ZorgtoeslagMain.php">Healthcare Allowance</a></li>
            </ul>
        </nav>
    </header>

    <!-- JS Script -->
    <script src="./../JScript/Navbar.js"></script>
</body>
</html>
