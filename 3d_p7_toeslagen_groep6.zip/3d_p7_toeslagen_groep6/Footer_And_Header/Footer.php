<?php
    echo '<link rel="stylesheet" href="../Footer_And_Header/Footer.css">';
?>
<footer>
    <div class="footer-container">
        <div class="footer-section">
            <h3>Contact</h3>
            <p>Tel: 0800-1234-5678</p>
            <br>
            <p>Email: support@gematax.nl</p>
            <br>
            <p>Twitter: @GemaTax_NL</p>
        </div>
        <div class="footer-section">
            <h3>Tax Services</h3>
            <ul>
                <li><a href="../Healthcare_Allowance/ZorgtoeslagMain.php">Healthcare Allowance</a></li>
                <li><a href="../Child_Allowance/KindertoeslagMain.php">Child Allowance</a></li>
                <li><a href="../Rental_Allowance/HuurtoeslagMain.php">Rental Allowance</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>More Information</h3>
            <ul>
                <li><a href="./../Info_Pages/Over_Ons.php">About GemaTax</a></li>
                <li><a href="./../Info_Pages/Offices.php">Our Offices</a></li>
                <li><a href="./../Info_Pages/FAQ.php">Frequently Asked Questions</a></li>
            </ul>
        </div>
        <img src="./../Pictures/Logo.png" alt="GemaTax logo" height="250px">
    </div>
</footer>
